# GecorCalculator
Calculator for negotiations at Gecor of Banco do Brasil.
